title: docker 安装 nginx
date: '2019-08-08 15:26:16'
updated: '2019-08-12 18:29:49'
tags: [Linux, Docker, Nginx, CentOS]
permalink: /articles/2019/08/08/1565249176000.html
---
#### 1. 查询本地镜像库
```
docker images nginx
```
> 如果没有
#### 2. 搜索镜像仓库
```
docker search nginx
```
> 根据需要选择
#### 3. 拉取镜像
```
docker pull nginx    # 拉取最新的官方 nginx 镜像
```
#### 4. 运行 `nginx` 镜像
```
docker run --name nginx -p 80:80 -d nginx
```
#### 5. 此时 `nginx` 已可以正常访问
> 地址 : ip, 端口设置的是 80, 所以省略.
```
Welcome to nginx!

If you see this page, the nginx web server is successfully installed and working. Further configuration is required.

For online documentation and support please refer to nginx.org.
Commercial support is available at nginx.com.

Thank you for using nginx.
```
>但是问题来了, 配置文件不是我们方便的位置, 我们需要把配置文件放到我们修改时候方便找到的地方.

#### 6. 拷贝配置文件到其他目录
```
# 新建存储目录
mkdir -p ~/nginx/www ~/nginx/logs ~/nginx/conf

 www: 目录将映射为 nginx 容器配置的虚拟目录
logs: 目录将映射为 nginx 容器的日志目录
conf: 目录里的配置文件将映射为 nginx 容器的配置文件

# 拷贝配置文件
docker cp nginx:/etc/nginx/nginx.conf ~/nginx/conf
```
#### 7. 删除当前 `nginx` 容器
```
# 停止运行
docker stop nginx

# 删除容器
docker rm nginx
```
#### 8. 重新运行 `nginx`
```
docker run -p 80:80 --name nginx -v ~/nginx/www:/usr/share/nginx/html -v ~/nginx/conf/nginx.conf:/etc/nginx/nginx.conf -v ~/nginx/logs:/var/log/nginx  -d nginx
```
#### 9. 访问 `nginx`
```
# 页面报错信息
403 Forbidden
nginx/1.17.2

# 查看错误日志
tail -fn 1000 ~/nginx/logs/error.log

2019/08/08 10:24:11 [error] 6#6: *1 directory index of "/usr/share/nginx/html/" is forbidden, client: 192.168.100.1, server: localhost, request: "GET / HTTP/1.1", host: "192.168.100.101"
2019/08/08 10:24:11 [error] 6#6: *1 open() "/usr/share/nginx/html/favicon.ico" failed (2: No such file or directory), client: 192.168.100.1, server: localhost, request: "GET /favicon.ico HTTP/1.1", host: "192.168.100.101"
```
#### 10. 在 `~/nginx/www` 目录新增 `index.html`
> 新建文件
```
touch index.html
```
> 编辑文件
```
vi index.html
```
> 进入编辑模式
```
i
```
> 文件内容
```html
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>www.chengzime.com.cn</title>
</head>
<body>
    <h1>Welcome to nginx!</h1>
</body>
</html>
```
> 退出编辑模式
```
Esc
```
> 保存退出
```
:wq
```
#### 11. 访问 `nginx`
```
Welcome to nginx!
```
### 成功结束
