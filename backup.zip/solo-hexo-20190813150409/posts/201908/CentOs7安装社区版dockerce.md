title: CentOs7 安装社区版 docker-ce
date: '2019-08-07 17:41:15'
updated: '2019-08-12 18:27:03'
tags: [Docker, Linux]
permalink: /articles/2019/08/07/1565170875000.html
---
#### 1. 查看是否已存在 `docker`
```
docker version
```

#### 2. 如果存在,删除旧版本 `docker`
```
yum remove docker \
              docker-client \
              docker-client-latest \
              docker-common \
              docker-latest \
              docker-latest-logrotate \
              docker-logrotate \
              docker-selinux \
              docker-engine-selinux \
              docker-engine
```
#### 3. 检查内核版本，返回的值大于3.10即可
```
uname -r
```
#### 4. 安装所需的软件包 
`yum-utils` 提供的 `yum-config-manager`
`device-mapper-persistent-data` 和 `lvm2`
```
yum install -y yum-utils device-mapper-persistent-data lvm2
```
#### 5. `yum-config-manager` 添加镜像源
```
yum-config-manager --add-repo http://mirrors.aliyun.com/docker-ce/linux/centos/docker-ce.repo
```
#### 6. 可以启用edge和测试存储库，默认是关闭
```
# 开启
yum-config-manager --enable docker-ce-edge
yum-config-manager --enable docker-ce-test

# 关闭
yum-config-manager --disable docker-ce-edge
yum-config-manager --disable docker-ce-test
```
#### 7. 安装 `docker-ce`
```
yum install docker-ce 
```
#### 8. 启动 `docker`
```
systemctl start docker  # centos7.x
service docker start    # centos6.x
```
#### 9. 查看 `docker` 状态
```
systemctl status docker
```
#### 10. 测试运行 `docker`
```
docker run hello-world
```
#### 11. 重新启动 `docker`
```
systemctl restart  docker  # centos7.x
service docker restart     # centos6.x
```
#### 12. 关闭 `docker`
```
systemctl stop docker  # centos7.x
service docker stop    # centos6.x
```
#### 13. 设置 `docker` 开机启动
```
systemctl enable docker
```
#### 14. 查看版本号
```
docker version
```
#### 15. 查看是否运行
```
ps -ef|grep docker
```
#### 16. 其他命令
```
# 查看容器日志
docker logs 容器名称/id

# 设置容器自动重启,默认是 no
docker update --restart=always 容器名称/id

# 查看是否在运行
docker ps

# 查看所有容器包括停止运行的
docker ps -a

# 停止容器
docker stop 容器名称/id

# 删除容器
docker rm 容器名称/id

# 查看所有镜像
docker images

# 查询镜像库
docker search mysql (项目名称)

# 拉取镜像
docker pull mysql:5.7 (项目名,可加版本号,用 : 隔开)

# 重启容器
docker restart 容器名称/id
```
