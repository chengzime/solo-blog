title: Linux 用户组合用户
date: '2019-10-29 15:24:42'
updated: '2019-10-30 18:05:03'
tags: [Linux, CentOS]
permalink: /articles/2019/10/29/1572333882648.html
---
![](https://img.hacpai.com/bing/20180903.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

### 1. 查看用户组列表
```
cat /etc/group
```
### 2. 新增用户组
```
groupadd  groupname
```
###3. 删除用户组
```
groupdel groupname
```
### 4. 查看用户列表
```
cat /etc/passwd
```
### 5. 新增用户
```
useradd username
```
### 6. 删除用户
```
userdel username
```
### 7. 新增用户并分组
```
useradd username -g groupname
```
### 8. 赋权
```
chown  -R  username:groupname  目录
```
### 9. 切换到账户
```
su username
```
### 10. 返回 `root` 账户
```
exit
```
