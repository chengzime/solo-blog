title: the default discovery settings are unsuitable for production use; at least
  one of [discovery.seed_hosts, discovery.seed_providers, cluster.initial_master_nodes]
  must be configured
date: '2019-10-28 17:54:14'
updated: '2019-10-28 17:54:14'
tags: [CentOS, elasticsearch, Linux]
permalink: /articles/2019/10/28/1572256454510.html
---
> 在 `Linux` 中安装 `elasticsearch` 的时候碰到了这个错误:
`the default discovery settings are unsuitable for production use; at least one of [discovery.seed_hosts, discovery.seed_providers, cluster.initial_master_nodes] must be configured`

### 解决办法:
- 在 `elasticsearch.yml` 配置文件中 添加: 
```
cluster.initial_master_nodes: ["node-1"]~~
```~~
