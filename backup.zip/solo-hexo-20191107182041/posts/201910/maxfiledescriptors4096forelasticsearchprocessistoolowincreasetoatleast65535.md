title: max file descriptors [4096] for elasticsearch process is too low, increase
  to at least [65535]
date: '2019-10-28 17:35:15'
updated: '2019-10-28 17:35:15'
tags: [elasticsearch, Linux, CentOS]
permalink: /articles/2019/10/28/1572255315321.html
---
> 在 `Linux` 中安装 `elasticsearch` 的时候碰到了这个错误:
`max file descriptors [4096] for elasticsearch process is too low, increase to at least [65535]`
### 解决方式:
- 切换回到 `root` 用户
```
su root
```
- 编辑配置文件
```
vi /etc/security/limits.conf
```
- 在文件最后添加
```
elastic soft nofile 65536
elastic hard nofile 65536
```
> 其中的 `elastic` 为运行 `es` 的用户名
- 切换回 `elastic` 用户运行问题解决
