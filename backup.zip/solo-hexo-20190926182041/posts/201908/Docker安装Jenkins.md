title: Docker 安装 Jenkins
date: '2019-08-19 17:13:16'
updated: '2019-08-21 22:13:57'
tags: [CentOS, Docker, Linux, JAVA]
permalink: /articles/2019/08/19/1566205996451.html
---
### 1. 查询 `Jenkins` 镜像
```
docker search jenkins
```
```
[root@bogon jenkins]# docker search jenkins
NAME                                         DESCRIPTION                                     STARS               OFFICIAL            AUTOMATED
jenkins                                      Official Jenkins Docker image                   4398                [OK]                
jenkins/jenkins                              The leading open source automation server       1637                                    
jenkinsci/blueocean                          https://jenkins.io/projects/blueocean           418                                     
jenkinsci/jenkins                            Jenkins Continuous Integration and Delivery …   367                                     
...
```
- jenkins 镜像为官方镜像, 版本较低, 安装插件很多不兼容
- jenkins/jenkins 为开发版
- jenkinsci/blueocean 官方推荐的捆绑了所有 Blue Ocean 插件的镜像
- 官方文档 https://jenkins.io/zh/doc/book/installing/

### 2. 拉取镜像
```
docker pull  jenkinsci/blueocean
```
> 这里选择的是第三个, 根据自己的需要进行拉取即可 

### 3. 查询镜像列表
```
docker images jenkinsci/blueocean
```
### 4. 创建目录并授权
```
mkdir -p /home/data/jenkins
```
- 这样还不够, 我们还需要指定用户, 要不然权限不够会报错
```
[root@bogon docker]# docker logs jenkins
touch: cannot touch '/var/jenkins_home/copy_reference_file.log': Permission denied
Can not write to /var/jenkins_home/copy_reference_file.log. Wrong volume permissions?
```
- 我们可以通过文档或者先启动不挂载目录的 `jenkins`, 查看到 `/var/jenkins_home` 所属用户 `UID` 和 `GID` 都为 `1000`

```
[root@bogon ~]# docker run  --name jenkins -p 9090:8080 -d jenkinsci/blueocean
55dfaf1570e81d9d3e0707ec3e724a2d05cad2a63094282408be2ee5317f01fe
[root@bogon ~]# docker exec -it jenkins bash
bash-4.4$ cd /var/jenkins_home/
bash-4.4$ ls -nd
drwxr-sr-x 14 1000 1000 4096 Aug 21 07:57 .
bash-4.4$ exit
[root@bogon ~]# docker stop jenkins
jenkins
[root@bogon ~]# docker rm jenkins
jenkins

```
- 为 `/home/data/jenkins/` 修改所属者和组
```
chown -R 1000:1000 /home/data/jenkins/
```

### 5. 安装镜像
```
docker run  --name jenkins -p 9090:8080 -p 50000:50000  --privileged=true -v /home/data/jenkins:/var/jenkins_home -v /var/run/docker.sock:/var/run/docker.sock -d jenkinsci/blueocean
```
> `-p 50000:50000` : 多个基于 `JNLP` 的 `Jenkins` 代理程序与 `jenkinsci/blueocean` 容器交互必需设置。基于 `JNLP` 的`Jenkins` 代理通过 `TCP` 端口 `50000` 与 `Jenkins` 主站进行通信。

>  `--privileged=true` : 给容器加特权, 在 `CentOS7` 中的安全模块 `selinux` 把权限禁掉了, `/usr/sbin/sestatus -v` 命令查询 `selinux` 是否开启.

> `-v /home/data/jenkins:/var/jenkins_home` : 把 `/home/data` 目录下的 `/jenkins` 目录挂载到 `jenkins` 容器中的配置目录 `/var/jenkins_home`

> `-v /var/run/docker.sock:/var/run/docker.sock` : 该映射允许 `jenkinsci/blueocean` 容器与 `Docker` 守护进程通信， 如果 `jenkinsci/blueocean` 容器需要实例化其他 `Docker` 容器，这个必须设置.

### 6. 查看日志
```
docker logs -f jenkins
```
```
[root@localhost ~]# docker logs jenkins...
Aug 20, 2019 2:34:59 AM jenkins.install.SetupWizard init
INFO: 

*************************************************************
*************************************************************
*************************************************************

Jenkins initial setup is required. An admin user has been created and a password generated.
Please use the following password to proceed to installation:

7c69a44d522e4968a1d77bf3602cf2a1     # 此为初始化密码

This may also be found at: /var/jenkins_home/secrets/initialAdminPassword

*************************************************************
*************************************************************
*************************************************************

```
**启动成功**

### 7. 访问 `Jenkins`
```
192.168.100.101:9090
```
- 此时, 我们发现 `Jenkins` 已经可以正常访问
- 页面提示我们输入密码, 首次打开需要获取管理员的密码

### 8. 获取初始化密码
```
cat /home/data/jenkins/secrets/initialAdminPassword
```
```
[root@bogon ~]# cat /home/data/jenkins/secrets/initialAdminPassword 
a66e9277fd7b473b991da12dab5f976b      # 此为初始化密码
```

### 9. 安装插件
- 我们输入初始化密码
- 进入了安装插件的界面
![Jenkins安装插件](http://www.qiniudns.chengzime.com.cn/FiJFcUV2ghZ4x5Vy__uZ1zTiDrYb)
- 我们选择第一个 - 推荐安装
- 因为网络问题有些插件可能没下载成功，重试一下, 是在下载不成功, 继续就好

### 10. 创建第一个管理用户
> # Create First Admin User
- 根据提示创建第一个管理用户
- 点击 Save and Finish

> # Jenkins is ready!
>
>  Your Jenkins setup is complete.

- 点击 Start using Jenkins


### 11. 修改插件源地址
刚才我们下载插件失败, 可能是因为网络不通, `Jenkins` 默认是从国外服务器下载, 我们这里把地址修改为国内的代理地址

- 点击左侧菜单的 **系统管理**
- 往下拉, 找到**管理插件**
- 在管理插件里点击**高级**
- 在下方有个**升级站点**
把原地址:
```
http://updates.jenkins-ci.org/update-center.json
```
修改为:
```
http://mirror.esuni.jp/jenkins/updates/update-center.json
```
- 提交

### 12. 手动下载插件的地址
下载Jenkins的插件的地址：https://plugins.jenkins.io

### 13. `/var/run/docker.sock: connect: permission denied`
```
Got permission denied while trying to connect to the Docker daemon socket at unix:///var/run/docker.sock: Post http://%2Fvar%2Frun%2Fdocker.sock/v1.39/images/create?fromImage=maven&tag=latest: dial unix /var/run/docker.sock: connect: permission denied
```
- 授权
```
chmod 777 /var/run/docker.sock

或者 

usermod -a -G docker jenkins
```
