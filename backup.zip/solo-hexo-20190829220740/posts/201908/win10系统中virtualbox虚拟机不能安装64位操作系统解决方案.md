title: win10 系统中 virtualbox 虚拟机不能安装 64 位操作系统解决方案
date: '2019-08-01 10:26:35'
updated: '2019-08-19 11:11:09'
tags: [CentOS, virtualbox, 虚拟机, Linux]
permalink: /articles/2019/08/01/1564626395000.html
---
在 `win10` 系统中安装虚拟机,却发现虚拟机列表里没有 `64` 位操作系统选项,只有 `32` 位的,怎么办?

#### 1. 查看是否已开启 `CPU` 虚拟化

- 打开 **任务管理器**
- 选择 **性能**
- 在 `cpu` 的信息里面有一个**虚拟化**
- 默认情况为**已禁用**状态,需要进入系统**bios**进行开启
- 下图为**已启用**状态


![cpu虚拟化查看](http://www.qiniudns.chengzime.com.cn/FhjzvvAkjUGFiamsgN0MeWajsgr9)

#### 2. `win10` 系统怎么进入 `bios` 呢?
- 点击 **开始菜单**
- 选择 **设置**
- 选择 **更新和安全**
- 在左侧菜单选择 **恢复**
- 找到 **高级启动** 下方的 **立即重新启动**, 电脑即进入重启状态

![进入电脑固件设置](http://www.qiniudns.chengzime.com.cn/FpzfdhSNxHvPsrAL6fI7Wmk6_Ais)

- 重启完成 进入了 选择界面


![选择疑难](http://www.qiniudns.chengzime.com.cn/FuvrJNsl6tQY88rlK6Zw9mLdlUSh)

- 点击 **高级选项**
- 选择 **UEFI固件设置**

![UEFI固件选择](http://www.qiniudns.chengzime.com.cn/FgwOUtFCEX12DTp5er7hiBPAwep9)

- 进入了 `bios` 设置
- 找到 `Intel Virtualization Technology` 选项,此时状态为`disabled`
- 按 回车键 `Enter` 选择 `Enable`,即开启
- 按 `F10` 保存, 选择 `Yes`,即保存完毕,进入重新启动
- 系统**启动**完毕
- 打开**资源管理器**发现 `cpu` 处的**虚拟化**状态为**已启动**
- 此时打开 **VirtulBox -> 新建**
- 发现已经可以选择**64位系统**了

![虚拟机选择64位系统](http://www.qiniudns.chengzime.com.cn/Fn-pgXDMaHN-Wf69sj6fHzkB8LWJ)

#### 3. **End**
