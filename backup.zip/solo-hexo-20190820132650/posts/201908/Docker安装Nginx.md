title: Docker 安装 Nginx
date: '2019-08-08 15:26:16'
updated: '2019-08-19 11:30:35'
tags: [Linux, Docker, Nginx, CentOS]
permalink: /articles/2019/08/08/1565249176000.html
---
#### 1. 查询本地镜像库
```
docker images nginx
```
> 如果没有
#### 2. 搜索镜像仓库
```
docker search nginx
```
> 根据需要选择
#### 3. 拉取镜像
```
docker pull nginx    # 拉取最新的官方 nginx 镜像
```
#### 4. 运行 `nginx` 镜像
```
docker run --name nginx -p 80:80 -d nginx
```
#### 5. 此时 `nginx` 已可以正常访问
地址 : ip, 端口设置的是 80, 所以省略.
```
Welcome to nginx!

If you see this page, the nginx web server is successfully installed and working. Further configuration is required.

For online documentation and support please refer to nginx.org.
Commercial support is available at nginx.com.

Thank you for using nginx.
```
但是问题来了, 配置文件不是我们方便的位置, 我们需要把配置文件放到我们修改时候方便找到的地方.
#### 6. 查看 `nginx` 容器文件目录
- 由于是在 `docker` 中的 `nginx` 容器,  所有配置文件都在容器内
- 查看配置文件
```
docker exec nginx ls /etc/nginx
```
```
[root@bogon ~]# docker exec nginx ls /etc/nginx
conf.d
fastcgi_params
koi-utf
koi-win
mime.types
modules
nginx.conf
scgi_params
uwsgi_params
win-utf
```
- 或者进入容器查看
```
docker exec -it nginx bash   #docker exec -it 容器id/名称 bash
```

```
[root@bogon ~]# docker exec -it nginx bash
root@e0788aee7e8b:/# ls
bin  boot  dev	etc  home  lib	lib64  media  mnt  opt	proc  root  run  sbin  srv  sys  tmp  usr  var
root@e0788aee7e8b:/# cd /etc/nginx/
root@e0788aee7e8b:/etc/nginx# ls
conf.d	fastcgi_params	koi-utf  koi-win  mime.types  modules  nginx.conf  scgi_params	uwsgi_params  win-utf
```
- 查看文件目录使用 `ls`, 使用 `ll` 是不支持的

- 编辑文件的命令 vi/vim 是不支持的, 需要安装插件

- 退出容器 `exit`
```
root@e0788aee7e8b:/etc/nginx# vi nginx.conf 
bash: vi: command not found
root@e0788aee7e8b:/etc/nginx# vim nginx.conf 
bash: vim: command not found
root@e0788aee7e8b:/etc/nginx# exit
exit
[root@bogon ~]# 
```
#### 7. 拷贝配置文件到其他目录

- 新建存储目录
```
mkdir -p ~/nginx/www ~/nginx/logs ~/nginx/conf
```
>  `www`: 目录将映射为 `nginx` 容器配置的虚拟目录
> `logs`: 目录将映射为 `nginx` 容器的日志目录
> `conf`: 目录里的配置文件将映射为 `nginx` 容器的配置文件

- 拷贝欢迎页
```
docker cp nginx:/usr/share/nginx/html/. ~/nginx/www
```
> 注意 `/usr/share/nginx/html/.` 最后有个 `.`, 如果漏了则会把 `html` 这个文件夹也一起复制到 `www` 文件夹下.

- 拷贝 `/etc/nginx` 下所有配置文件到 `~/nginx/conf`
```
docker cp nginx:/etc/nginx/. ~/nginx/conf
```
> 注意 `/etc/nginx/.` 最后有个 `.`, 如果漏了则会把 `nginx` 这个文件夹也一起复制到 `conf` 文件夹下.

> 或者, 你也可以只拷贝 `/etc/nginx/nginx.conf` 配置文件 `docker cp nginx:/etc/nginx/nginx.conf ~/nginx/conf`

#### 8. 删除当前 `nginx` 容器

- 停止运行
```
docker stop nginx
```

- 删除容器
```
docker rm nginx
```

#### 9. 重新运行 `nginx`
```
docker run -p 80:80 -p 443:443 --name nginx -v ~/nginx/www:/usr/share/nginx/html -v ~/nginx/conf/:/etc/nginx/ -v ~/nginx/logs:/var/log/nginx  -d nginx
```
> ` -p 80:80 ` : 把服务器的 `80` 端口映射到容器 `80` 端口, 用于 `http`

> ` -p 443:443 ` : 把服务器的 `443` 端口映射到容器 `443` 端口, 用于 `https`

> 或者, 如果你只复制了 `/etc/nginx/nginx.conf`, 执行 :
`docker run -p 80:80 -p 443:443 --name nginx -v ~/nginx/www:/usr/share/nginx/html -v ~/nginx/conf/nginx.conf:/etc/nginx/nginx.conf -v ~/nginx/logs:/var/log/nginx  -d nginx`
#### 10. 访问 `nginx`
```
Welcome to nginx!

If you see this page, the nginx web server is successfully installed and working. Further configuration is required.

For online documentation and support please refer to nginx.org.
Commercial support is available at nginx.com.

Thank you for using nginx.
```
#### 11. 设置自动重启
```
# 设置容器自动重启,默认是 no  
docker  update --restart=always nginx
```
### 成功结束
