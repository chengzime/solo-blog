title: 使用通用mapper时在xml自定义一对多 异常No typehandler found for property likeList
date: '2019-07-15 11:14:55'
updated: '2019-09-20 18:43:41'
tags: [通用Mapper, Mybatis, JAVA]
permalink: /articles/2019/07/15/1563160495000.html
---
通用 `mapper` 因为能够极大的提高我们的开发效率,所以在日常开发中已经有越来    越多的人在使用它,虽然通用 `mapper` 已经给我们封装好了很多的方法供我们直接使用,但是还是有一些情况我们需要自定义 `sql` 来应对不同的场景.
    
前几天在写一个小功能的时候在 `xml` 中自定义了一个一对多查询,代码如下


##### 实体类
```java
package cn.com.chengzime.domain.model;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import lombok.experimental.Accessors;

import javax.persistence.Column;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.List;

/**
 * 说明:
 *
 * @author :chengzi
 * Create :2019/7/8 16:53
 */
@Getter
@Setter
@ToString
@Accessors(chain = true)
@Table(name = "user")
public class User {

    /**
     * id
     */
    @Id
    @Column(name = "id")
    private Integer id;

    /**
     * 名称
     */
    @Column(name = "name")
    private String name;

    /**
     * 年龄
     */
    @Column(name = "age")
    private Integer age;


    @Column(name = "likeList")
    private List<Like> likeList;
}
```
##### xml
```xml
  <resultMap id="BaseResultMap" type="cn.com.chengzime.domain.model.User">
    <id column="id" jdbcType="INTEGER" property="id" />
    <result column="name" jdbcType="VARCHAR" property="name" />
    <result column="age" jdbcType="INTEGER" property="age" />
    <collection property="likeList" ofType="cn.com.chengzime.domain.model.Like">
      <result column="like_name" jdbcType="VARCHAR" property="likeName" />
    </collection>
  </resultMap>

  <select id="listUserLike" resultMap="BaseResultMap">
    select
        u.id,
        u.name,
        u.age,
        l.like_name
    from user u left join like l
        on u.id = l.user_id
  </select>

```
##### 异常信息
```java
Caused by: tk.mybatis.mapper.MapperException: java.lang.IllegalStateException: No typehandler found for property likeList
at tk.mybatis.mapper.mapperhelper.MapperTemplate.setSqlSource(MapperTemplate.java:188)
at tk.mybatis.mapper.mapperhelper.MapperHelper.setSqlSource(MapperHelper.java:245)
... 55 more
Caused by: java.lang.IllegalStateException: No typehandler found for property likeList
at org.apache.ibatis.mapping.ResultMapping$Builder.validate(ResultMapping.java:151)
at org.apache.ibatis.mapping.ResultMapping$Builder.build(ResultMapping.java:140)
at tk.mybatis.mapper.entity.EntityTable.getResultMap(EntityTable.java:228)
at tk.mybatis.mapper.mapperhelper.MapperTemplate.setResultType(MapperTemplate.java:137)
at tk.mybatis.mapper.provider.base.BaseSelectProvider.select(BaseSelectProvider.java:69)
at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
at java.lang.reflect.Method.invoke(Method.java:498)
at tk.mybatis.mapper.mapperhelper.MapperTemplate.setSqlSource(MapperTemplate.java:178)
... 56 more
```

运行时发生异常,信息是没有找到 `likeList` 属性,进行排查发现问题出在实体类中, `user` 表中其实是没有 `likeList` 字段的,我们在 `user` 实体类中添加此属性之后,通用 `mapper` 在解析的时候发现表中没有此字段,无法完成字段映射,所以抛出了此异常,针对这种问题,通用 `mapper` 提供了 `@Transient` 注解,我们可以在实体类中对某些字段进行标注,告诉通用 `mapper` 忽略此字段:
```java
    import javax.persistence.Transient;

    @Transient
    private List<Like> likeList;
```
这样,再次运行,我们发现异常成功解决了. 
