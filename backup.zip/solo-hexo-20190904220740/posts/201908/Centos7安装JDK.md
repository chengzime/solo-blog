title: Centos7 安装 JDK
date: '2019-08-07 18:13:56'
updated: '2019-08-12 18:27:46'
tags: [CentOS, JDK, Linux, JAVA]
permalink: /articles/2019/08/07/1565172836000.html
---
#### 1. 在 `usr` 目录下建立 `java` 安装目录
```
mkdir /usr/java
```
#### 2. 把下载好的 `JDK` 包上传到服务器 `/usr/java` 目录下
可以使用 `xftp` 等, 进入 `java` 目录
```
cd /usr/java
```
#### 3. 解压 `JDK` 到当前目录
```
tar -zxvf jdk-8u212-linux-x64.tar.gz
```
#### 4. 可以为 `JDK` 建立一个快捷目录(可选)
```
ln -s /usr/java/jdk1.8.0_212/ /usr/jdk
```
#### 5. 配置环境变量
```
vim /etc/profile
# 或者
vi /etc/profile
```
按 `i` 键进入输入模式, 此时下方出现 `--insert--` 字样, 移动光标到最下方开始新增配置:
```
export JAVA_HOME=/usr/java/jdk1.8.0_212   # 此处根据自己实际路径
export JRE_HOME=${JAVA_HOME}/jre
export CLASSPATH=.:${JAVA_HOME}/lib:${JRE_HOME}/lib:$CLASSPATH
export JAVA_PATH=${JAVA_HOME}/bin:${JRE_HOME}/bin
export PATH=$PATH:${JAVA_PATH}
```
配置完成后,按 `Esc` 键退出编辑模式, `--insert--` 字样消失
输入小写的 `:wq` **保存配置**退出 `vi` 模式.
如果**不想保存**, 输入小写 `:q!` 不保存退出.
#### 6. 配置生效
```
source /etc/profile
```
或者重启也可以
```
shutdown -r now
```
#### 7. 查看安装情况
```
java -version

# 打印
java version "1.8.0_212"
Java(TM) SE Runtime Environment (build 1.8.0_212-b10)
Java HotSpot(TM) 64-Bit Server VM (build 25.212-b10, mixed mode)
```
成功安装!
