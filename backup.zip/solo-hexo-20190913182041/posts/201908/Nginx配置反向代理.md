title: Nginx 配置反向代理
date: '2019-08-15 18:16:56'
updated: '2019-08-19 11:50:40'
tags: [CentOS, Docker, Linux, Nginx]
permalink: /articles/2019/08/15/1565864216388.html
---
#### 1. 安装 `Nginx` 请查看之前的帖子

#### 2. 找到 `Nginx` 的 `conf.d` 目录
- 默认是在 `/etc/nginx/` 目录下
- 如果使用 `Docker` 安装的 `Nginx` 容器, 并且挂载了配置目录或文件, 则去自己设置的目录下寻找
- 我的目录挂载在了 `~/nginx/conf` 目录下面

#### 3. 复制 `conf.d` 下的 `default.conf` 文件
```
cp default.conf chengzi.conf
```
```
[root@localhost ~]# cd nginx/conf/conf.d/
[root@localhost conf.d]# cp default.conf chengzi.conf
[root@localhost conf.d]# ls
default.conf  chengzi.conf
```
#### 4. 修改 复制来的配置文件
- 进入 `vim` 模式
```
vi chengzi.conf
```
```
[root@localhost conf.d]# vi chengzi.conf 

server {
    listen       80;
    server_name  localhost;

    #charset koi8-r;
    #access_log  /var/log/nginx/host.access.log  main;

    location / {
        root   /usr/share/nginx/html;
        index  index.html index.htm;
    }

    #error_page  404              /404.html;

    # redirect server error pages to the static page /50x.html
    #
    error_page   500 502 503 504  /50x.html;
    location = /50x.html {
        root   /usr/share/nginx/html;
    }

    # proxy the PHP scripts to Apache listening on 127.0.0.1:80
    #
    #location ~ \.php$ {
    #    proxy_pass   http://127.0.0.1;
    #}

    # pass the PHP scripts to FastCGI server listening on 127.0.0.1:9000
    #
    #location ~ \.php$ {
    #    root           html;
    #    fastcgi_pass   127.0.0.1:9000;
    #    fastcgi_index  index.php;
    #    fastcgi_param  SCRIPT_FILENAME  /scripts$fastcgi_script_name;
    #    include        fastcgi_params;
    #}

    # deny access to .htaccess files, if Apache's document root
    # concurs with nginx's one
    #
    #location ~ /\.ht {
    #    deny  all;
    #}
}
```
- 按 `i` 进入编辑模式

- 找到 这些配置
``` 
    listen       80;   
    server_name  localhost;  

    #charset koi8-r;
    #access_log  /var/log/nginx/host.access.log  main;

    location / {
        root   /usr/share/nginx/html;
        index  index.html index.htm;
    }
 
```
- 修改为
```
    listen       80;   # 监听的对外请求端口
    server_name  192.168.100.101;  # 监听的对外请求地址

    #charset koi8-r;
    #access_log  /var/log/nginx/host.access.log  main;

    # 反向代理修改这里
    location / {
        #root   /usr/share/nginx/html;
        #index  index.html index.htm;
        proxy_set_header Host $host;
        proxy_set_header X-Real-Ip $remote_addr;
        proxy_set_header X-Forwarded-For $remote_addr;
        proxy_pass http://192.168.100.101:8080;  # 项目请求地址
    }
```
- 按 `Esc` 退出编辑模式

- 输入 `:wq` 保存退出

#### 5. 重启 `Nginx`
- 如果不是在 `Docker` 容器安装的 `Nginx` , 使用 `nginx -s reload` 重新加载配置
- 如果是 `Docker` 容器安装的 `Nginx` , 使用 `docker restart nginx` 重启 `Nginx`, `docker restart 容器名称/id`

#### 6. 访问 `192.168.100.101` 正常转发到了 `192.168.100.101:8080`


