title: Docker 安装 Jenkins
date: '2019-08-19 17:13:16'
updated: '2019-08-20 18:50:51'
tags: [CentOS, Docker, Linux, JAVA]
permalink: /articles/2019/08/19/1566205996451.html
---
#### 1. 查询 `Jenkins` 镜像
```
docker search jenkins
```
```
[root@bogon jenkins]# docker search jenkins
NAME                                         DESCRIPTION                                     STARS               OFFICIAL            AUTOMATED
jenkins                                      Official Jenkins Docker image                   4398                [OK]                
jenkins/jenkins                              The leading open source automation server       1637                                    
jenkinsci/blueocean                          https://jenkins.io/projects/blueocean           418                                     
jenkinsci/jenkins                            Jenkins Continuous Integration and Delivery …   367                                     
jenkinsci/jnlp-slave                         A Jenkins slave using JNLP to establish conn…   113                                     [OK]
jenkins/jnlp-slave                           a Jenkins agent (FKA "slave") using JNLP to …   93                                      [OK]
jenkinsci/slave                              Base Jenkins slave docker image                 56                                      [OK]
cloudbees/jenkins-enterprise                 CloudBees Jenkins Enterprise (Rolling releas…   33                                      [OK]
jenkins/slave                                base image for a Jenkins Agent, which includ…   30                                      [OK]
h1kkan/jenkins-docker                        🤖 Extended Jenkins docker image, bundled wi…    24                                      
openshift/jenkins-2-centos7                  A Centos7 based Jenkins v2.x image for use w…   20                                      
bitnami/jenkins                              Bitnami Docker Image for Jenkins                18                                      [OK]
cloudbees/jenkins-operations-center          CloudBees Jenkins Operation Center (Rolling …   13                                      [OK]
blacklabelops/jenkins                        Docker Jenkins Swarm-Ready with HTTPS and Pl…   13                                      [OK]
fabric8/jenkins-docker                       Fabric8 Jenkins Docker Image                    10                                      [OK]
vfarcic/jenkins-swarm-agent                  Jenkins agent based on the Swarm plugin         8                                       [OK]
openshift/jenkins-slave-base-centos7         A Jenkins slave base image. DEPRECATED: see …   6                                       
publicisworldwide/jenkins-slave              Jenkins Slave based on Oracle Linux             5                                       [OK]
openshift/jenkins-1-centos7                  DEPRECATED: A Centos7 based Jenkins v1.x ima…   4                                       
camper83/jenkins-slave-with-docker-compose   jenkins slave with docker compose               4                                       [OK]
trion/jenkins-docker-client                  Jenkins CI server with docker client            3                                       [OK]
amazeeio/jenkins-slave                       A jenkins slave that connects to a master vi…   0                                       [OK]
jameseckersall/jenkins                       docker-jenkins (based on openshift jenkins 2…   0                                       [OK]
ansibleplaybookbundle/jenkins-apb            An APB which deploys Jenkins CI                 0                                       [OK]
mashape/jenkins                              Just a jenkins image with the AWS cli added …   0                                       [OK]

```
- jenkins 镜像为官方镜像, 版本较低, 安装插件不兼容
- jenkins/jenkins 为抢先版
- jenkinsci/blueocean 官方推荐的捆绑了所有 Blue Ocean 插件的镜像
- 官方文档 https://jenkins.io/zh/doc/book/installing/

#### 2. 拉取镜像
```
docker pull  jenkinsci/blueocean
```
> 这里选择的是第三个, 根据自己的需要进行拉取即可 

#### 3. 查询镜像列表
```
docker images jenkinsci/blueocean
```
#### 4. 安装镜像
```
docker run  --name jenkins -p 9090:8080 -p 50000:50000 -v /home/data/jenkins:/var/jenkins_home -v /var/run/docker.sock:/var/run/docker.sock -d jenkinsci/blueocean
```
- `--name jenkins` : 设置容器名称为 `jenkins`
- `-p 9090:8080` : 把系统的 `9090` 端口转发到容器的 `8080` 端口
- `-p 50000:50000` : 如果您在其他机器上设置了一个或多个基于JNLP的Jenkins代理程序，而这些代理程序又与 `jenkinsci/blueocean` 容器交互（充当“主” `Jenkins` 服务器，或者简称为 `“Jenkins主”` ）， 则这是必需的。默认情况下，基于 `JNLP` 的`Jenkins` 代理通过 `TCP` 端口 `50000` 与 `Jenkins` 主站进行通信。 您可以通过“ 配置全局安全性” 页面更改 `Jenkins` 主服务器上的端口号。
- `-v /home/data/jenkins:/var/jenkins_home` : 把 `root` 目录下的 `jenkins` 目录挂载到 `jenkins` 容器中的配置目录 `/var/jenkins_home`
- `-d jenkinsci/blueocean` :  在后台运行容器
- `-v /var/run/docker.sock:/var/run/docker.sock` : 该映射允许 `jenkinsci/blueocean` 容器与 `Docker` 守护进程通信， 如果 `jenkinsci/blueocean` 容器需要实例化其他 `Docker` 容器，则该守护进程是必需的。 
- 如果进行了上一个配置, 需要对 `/var/run/docker.sock` 进行授权, 否则会报错
```
Got permission denied while trying to connect to the Docker daemon socket at unix:///var/run/docker.sock: Post http://%2Fvar%2Frun%2Fdocker.sock/v1.39/images/create?fromImage=maven&tag=latest: dial unix /var/run/docker.sock: connect: permission denied
```
- 授权
```
chmod 777 /var/run/docker.sock

或者 

usermod -a -G docker jenkins~~~~
```
#### 5. 查看 `Jenkins` 日志
```
docker logs jenkins
```
```
[root@bogon docker]# docker logs jenkins
touch: cannot touch '/var/jenkins_home/copy_reference_file.log': Permission denied
Can not write to /var/jenkins_home/copy_reference_file.log. Wrong volume permissions?
```
> 发现我们新建的目录权限不够

#### 6. 进行授权
```
chmod -R 777 /home/data/jenkins/
```
#### 7. 查看日志
```
docker logs jenkins
```
```
[root@localhost ~]# docker logs jenkins
touch: cannot touch '/var/jenkins_home/copy_reference_file.log': Permission denied
Can not write to /var/jenkins_home/copy_reference_file.log. Wrong volume permissions?
Running from: /usr/share/jenkins/jenkins.war
webroot: EnvVars.masterEnvVars.get("JENKINS_HOME")
Aug 20, 2019 2:33:57 AM org.eclipse.jetty.util.log.Log initialized
INFO: Logging initialized @1694ms to org.eclipse.jetty.util.log.JavaUtilLog
Aug 20, 2019 2:33:58 AM winstone.Logger logInternal
INFO: Beginning extraction from war file
Aug 20, 2019 2:34:00 AM org.eclipse.jetty.server.handler.ContextHandler setContextPath
WARNING: Empty contextPath
Aug 20, 2019 2:34:00 AM org.eclipse.jetty.server.Server doStart
INFO: jetty-9.4.z-SNAPSHOT; built: 2019-02-15T16:53:49.381Z; git: eb70b240169fcf1abbd86af36482d1c49826fa0b; jvm 1.8.0_212-b04
Aug 20, 2019 2:34:01 AM org.eclipse.jetty.webapp.StandardDescriptorProcessor visitServlet
INFO: NO JSP Support for /, did not find org.eclipse.jetty.jsp.JettyJspServlet
Aug 20, 2019 2:34:01 AM org.eclipse.jetty.server.session.DefaultSessionIdManager doStart
INFO: DefaultSessionIdManager workerName=node0
Aug 20, 2019 2:34:01 AM org.eclipse.jetty.server.session.DefaultSessionIdManager doStart
INFO: No SessionScavenger set, using defaults
Aug 20, 2019 2:34:01 AM org.eclipse.jetty.server.session.HouseKeeper startScavenging
INFO: node0 Scavenging every 600000ms
Jenkins home directory: /var/jenkins_home found at: EnvVars.masterEnvVars.get("JENKINS_HOME")
Aug 20, 2019 2:34:04 AM org.eclipse.jetty.server.handler.ContextHandler doStart
INFO: Started w.@72c927f1{Jenkins v2.176.2,/,file:///var/jenkins_home/war/,AVAILABLE}{/var/jenkins_home/war}
Aug 20, 2019 2:34:04 AM org.eclipse.jetty.server.AbstractConnector doStart
INFO: Started ServerConnector@245a26e1{HTTP/1.1,[http/1.1]}{0.0.0.0:8080}
Aug 20, 2019 2:34:04 AM org.eclipse.jetty.server.Server doStart
INFO: Started @8887ms
Aug 20, 2019 2:34:04 AM winstone.Logger logInternal
INFO: Winstone Servlet Engine v4.0 running: controlPort=disabled
Aug 20, 2019 2:34:07 AM org.kohsuke.stapler.LocaleDrivenResourceProvider getLocaleDrivenResourceProviders
INFO: Registered LocaleDrivenResourceProvider: jenkins.MetaLocaleDrivenResourceProvider@6e9762f5
Aug 20, 2019 2:34:11 AM jenkins.InitReactorRunner$1 onAttained
INFO: Started initialization
Aug 20, 2019 2:34:13 AM hudson.PluginManager considerDetachedPlugin
INFO: Loading a detached plugin as a dependency: /var/jenkins_home/plugins/bouncycastle-api.jpi
Aug 20, 2019 2:34:13 AM hudson.PluginManager considerDetachedPlugin
INFO: Loading a detached plugin as a dependency: /var/jenkins_home/plugins/command-launcher.jpi
Aug 20, 2019 2:34:13 AM hudson.PluginManager considerDetachedPlugin
INFO: Loading a detached plugin as a dependency: /var/jenkins_home/plugins/jdk-tool.jpi
Aug 20, 2019 2:34:18 AM jenkins.InitReactorRunner$1 onAttained
INFO: Listed all plugins
Aug 20, 2019 2:34:18 AM jenkins.bouncycastle.api.SecurityProviderInitializer addSecurityProvider
INFO: Initializing Bouncy Castle security provider.
Aug 20, 2019 2:34:20 AM jenkins.bouncycastle.api.SecurityProviderInitializer addSecurityProvider
INFO: Bouncy Castle security provider initialized.
Aug 20, 2019 2:34:46 AM jenkins.InitReactorRunner$1 onAttained
INFO: Prepared all plugins
Aug 20, 2019 2:34:46 AM jenkins.InitReactorRunner$1 onAttained
INFO: Started all plugins
Aug 20, 2019 2:34:54 AM jenkins.InitReactorRunner$1 onAttained
INFO: Augmented all extensions
Aug 20, 2019 2:34:55 AM jenkins.InitReactorRunner$1 onAttained
INFO: Loaded all jobs
Aug 20, 2019 2:34:55 AM hudson.model.AsyncPeriodicWork$1 run
INFO: Started Download metadata
Aug 20, 2019 2:34:55 AM hudson.util.Retrier start
INFO: Attempt #1 to do the action check updates server
Aug 20, 2019 2:34:58 AM org.springframework.context.support.AbstractApplicationContext prepareRefresh
INFO: Refreshing org.springframework.web.context.support.StaticWebApplicationContext@183e0896: display name [Root WebApplicationContext]; startup date [Tue Aug 20 02:34:58 GMT 2019]; root of context hierarchy
Aug 20, 2019 2:34:58 AM org.springframework.context.support.AbstractApplicationContext obtainFreshBeanFactory
INFO: Bean factory for application context [org.springframework.web.context.support.StaticWebApplicationContext@183e0896]: org.springframework.beans.factory.support.DefaultListableBeanFactory@6929ce9e
Aug 20, 2019 2:34:58 AM org.springframework.beans.factory.support.DefaultListableBeanFactory preInstantiateSingletons
INFO: Pre-instantiating singletons in org.springframework.beans.factory.support.DefaultListableBeanFactory@6929ce9e: defining beans [authenticationManager]; root of factory hierarchy
Aug 20, 2019 2:34:58 AM org.springframework.context.support.AbstractApplicationContext prepareRefresh
INFO: Refreshing org.springframework.web.context.support.StaticWebApplicationContext@4621bbbd: display name [Root WebApplicationContext]; startup date [Tue Aug 20 02:34:58 GMT 2019]; root of context hierarchy
Aug 20, 2019 2:34:58 AM org.springframework.context.support.AbstractApplicationContext obtainFreshBeanFactory
INFO: Bean factory for application context [org.springframework.web.context.support.StaticWebApplicationContext@4621bbbd]: org.springframework.beans.factory.support.DefaultListableBeanFactory@345f773f
Aug 20, 2019 2:34:58 AM org.springframework.beans.factory.support.DefaultListableBeanFactory preInstantiateSingletons
INFO: Pre-instantiating singletons in org.springframework.beans.factory.support.DefaultListableBeanFactory@345f773f: defining beans [filter,legacy]; root of factory hierarchy
Aug 20, 2019 2:34:59 AM jenkins.install.SetupWizard init
INFO: 

*************************************************************
*************************************************************
*************************************************************

Jenkins initial setup is required. An admin user has been created and a password generated.
Please use the following password to proceed to installation:

7c69a44d522e4968a1d77bf3602cf2a1     # 此为初始化密码

This may also be found at: /var/jenkins_home/secrets/initialAdminPassword

*************************************************************
*************************************************************
*************************************************************

```
> 启动成功

#### 8. 访问 `Jenkins`
```
192.168.100.101:9090
```
- 此时, 我们发现 `Jenkins` 已经可以正常访问
- 页面提示我们输入密码, 首次打开需要获取管理员的密码

#### 9. 获取初始化密码
```
cat jenkins/secrets/initialAdminPassword
```
```
[root@bogon ~]# cat jenkins/secrets/initialAdminPassword 
a66e9277fd7b473b991da12dab5f976b      # 此为初始化密码
```
- Jenkins 的配置目录
```
[root@bogon docker]# cd
[root@bogon ~]# cd jenkins/
[root@bogon jenkins]# ls
config.xml                     identity.key.enc  jenkins.install.UpgradeWizard.state  nodeMonitors.xml  secret.key                updates      war
copy_reference_file.log        init.groovy.d     jobs                                 nodes             secret.key.not-so-secret  userContent
hudson.model.UpdateCenter.xml  jenkins.CLI.xml   logs                                 plugins           secrets                   users
[root@bogon jenkins]# cat secrets/
cat: secrets/: 是一个目录
[root@bogon jenkins]# cd secrets/
[root@bogon secrets]# ls
filepath-filters.d    jenkins.model.Jenkins.crumbSalt         org.jenkinsci.main.modules.instance_identity.InstanceIdentity.KEY
hudson.util.Secret    jenkins.security.ApiTokenProperty.seed  slave-to-master-security-kill-switch
initialAdminPassword  master.key                              whitelisted-callables.d
[root@bogon secrets]# cat initialAdminPassword 
a66e9277fd7b473b991da12dab5f976b
```
#### 10. 安装插件
- 我们输入初始化密码
- 进入了安装插件的界面
![Jenkins安装插件](http://www.qiniudns.chengzime.com.cn/FiJFcUV2ghZ4x5Vy__uZ1zTiDrYb)
- 我们选择第一个 - 推荐安装
- 因为网络问题有些插件可能没下载成功，重试一下, 是在下载不成功, 继续就好

#### 11. 创建第一个管理用户
> # Create First Admin User
- 根据提示创建第一个管理用户
- 点击 Save and Finish

> # Jenkins is ready!
>
>  Your Jenkins setup is complete.

- 点击 Start using Jenkins

#### 12. 修改插件源地址
刚才我们下载插件失败, 可能是因为网络不通, `Jenkins` 默认是从国外服务器下载, 我们这里把地址修改为国内的代理地址

- 点击左侧菜单的 **系统管理**
- 往下拉, 找到**管理插件**
- 在管理插件里点击**高级**
- 在下方有个**升级站点**
把原地址:
```
http://updates.jenkins-ci.org/update-center.json
```
修改为:
```
http://mirror.esuni.jp/jenkins/updates/update-center.json
```
- 提交

#### 13. 手动下载插件的地址
下载Jenkins的插件的地址：https://plugins.jenkins.io
