title: Docker 查看容器日志各种常用命令
date: '2019-08-13 18:57:55'
updated: '2019-08-13 18:57:55'
tags: [Docker, Linux]
permalink: /articles/2019/08/13/1565693875276.html
---
#### 1. 一般命令
> 此命令打印容器的日志, 打印完成直接结束
```
docker logs 容器名称/id
```
#### 2. 个性化命令
```
docker logs [OPTIONS] 容器名称/id
```
> `Options` 常用的值
```
-f 或 --follow             同 Linux, 持续跟踪日志
-t 或 --timestamps         在行首显示日志时间
      --tail [行数]        同 Linux, 显示日志总行数, 默认是all
      --since [时间]       显示自具体某个时间或时间段之后的日志
      --until [时间]       显示自具体某个时间或时间段之前的日志
```
#### 3. 跟踪日志
> 查询日志, 并且持续跟踪日志
```
docker logs -f solo
```
#### 4. 显示日志时间
```
docker logs -f -t solo
```
#### 5. 显示最后 `1000` 行日志
```
docker logs -f --tail solo
```
#### 6. 显示某时间之后的日志
> 查询 `2017-08-13T18:11:00` 时间之后的日志
```
docker logs -f --since "2017-08-13T18:11:00"  solo
```
> 查询 `10m` 之后的日志
```
docker logs -f --since 10m solo
```
#### 7. 显示某时间之前的日志
> 查询 `2017-08-13T18:11:00` 时间之后的日志
```
docker logs --until "2017-08-13T18:11:00"  solo
```
> 查询 `10m` 之后的日志
```
docker logs --until 10m solo
```
#### 8. 显示某段时间之间的日志
> 查询 `08-13` 到 `09-13` 之间的日志
```
docker logs --since "2017-08-13T18:11:00" --until "2017-09-13T18:11:00"  solo
```

