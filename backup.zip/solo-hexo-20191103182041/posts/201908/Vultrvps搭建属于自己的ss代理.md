title: Vultr vps 搭建属于自己的 ss 代理
date: '2019-08-22 16:53:50'
updated: '2019-08-22 17:01:23'
tags: [ss, shadowsocks, vultr]
permalink: /articles/2019/08/22/1566464030235.html
---
> 原文 :  https://www.iwannerfuck.xyz/

> 内容记录下来做笔记预防丢失

## 1. 选择优质的 `VPS`
简单介绍：`Vultr` 作为全球最大的游戏主机提供商背景之一，上线之后以高质的性价比、遍布全球 `16` 个数据中心，以及新注册用户不定期有美金赠送，吸引广大的用户。  
而且操作简单方便，一键部署，性能目前测试非常不错。支付是采用充值的方式，支持国内 **支付宝** 支付，**微信扫码** 支付。按照VPS开通使用情况每小时扣款，不象很多其他 `VPS` 要求一次买 `2` 年或者 `1` 年的，非常人性化。

## 2. 注册vultr账号
- [Get started in the Vultr SSD Cloud!](https://www.vultr.com/?ref=8233642) 此为邀请链接, 充值送 50$
- 进入网站之后填写注册邮箱、密码 （最少10位，要同时有数字和大小写字母） ，点击create account。
![image.png](https://img.hacpai.com/file/2019/08/image-b05fecbf.png)

- **然后点击左边栏Billing跳转到充值页面=>**
![image.png](https://img.hacpai.com/file/2019/08/image-65d73f18.png)

- 这时就可以用alipay（支付宝）或者微信扫码付款充值，相信大家轻松搞定。
- 我用的微信的, 比支付宝便宜一块左右
- 付款完成刷新页面, 会看到账户余额 `60$`
![image.png](https://img.hacpai.com/file/2019/08/image-7b65e42a.png)

## 3. 搭建服务
![image.png](https://img.hacpai.com/file/2019/08/image-8751eef7.png)
**然后选择服务器节点位置以及相关配置，按下图依次选择配置：**
![image.png](https://img.hacpai.com/file/2019/08/image-3a9739a8.png)
**然后选择操作系统、以及收费级别=>**
![image.png](https://img.hacpai.com/file/2019/08/image-3dc825af.png)

**然后会自动跳转到Products界面=>**
![image.png](https://img.hacpai.com/file/2019/08/image-7feab3af.png)

**记录服务器相关信息=>**
![image.png](https://img.hacpai.com/file/2019/08/image-df3024ec.png)

## 4. 使用 Xshell 终端连接到服务器、生成ss账号
- 安装 `shadowsocks`
- 第一条命令
```
wget --no-check-certificate https://raw.githubusercontent.com/teddysun/shadowsocks_install/master/shadowsocks.sh
```
- 等待下载完成
- 第二条命令
```
chmod +x shadowsocks.sh
```
- 第三条命令
```
./shadowsocks.sh 2>&1 | tee shadowsocks.log
```
> **中间会提示你输入你的SS SERVER的账号，和端口。不输入就是默认。跑完命令后会出来你的SS客户端的信息。特别注意，由于iphone端的目前只支持到cfb，所以我们选择aes-256-cfb，即7，这一步按回车继续然后需要几分钟的安装过程，请耐心等待出现下面的画面！**

![image.png](https://img.hacpai.com/file/2019/08/image-504cd763.png)

> 请立即copy下来加以保存。记录保存好你的上述信息：Server IP、Server Port、Password、Encryption Method。这时你的专属ss已经搭好了，开始使用吧。

###  5. 客户端设置
- 去 `github` 下载对应系统的客户端
https://github.com/shadowsocks/shadowsocks-windows/releases

- 安装 `shadowsocks`
- 根据刚才保存的设置信息, 进行填写
- 填写完成之后
![image.png](https://img.hacpai.com/file/2019/08/image-2c9e59ba.png)

