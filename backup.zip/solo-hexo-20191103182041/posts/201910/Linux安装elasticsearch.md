title: Linux 安装 elasticsearch
date: '2019-10-28 17:30:44'
updated: '2019-10-29 17:38:42'
tags: [elasticsearch, CentOS, Linux]
permalink: /articles/2019/10/28/1572255044387.html
---
> 使用的 `centos 7.x`
### 1. 下载地址: 
https://www.elastic.co/cn/products/elastic-stack
> 下载完成导入 `linux`
### 2. 解压
```
tar -zxvf elasticsearch-7.4.1-linux-x86_64.tar.gz
```
> 配置
```
thread_pool.write.queue_size: 1000
node.name: node-1 #节点名称
#设置绑定的ip，设置为0.0.0.0以后就可以让任何计算机节点访问到了
network.host: 0.0.0.0
http.port: 9200 #端口
#设置在集群中的所有节点名称，这个节点名称就是之前所修改的，当然你也可以采用默认的也行，目前是单机，放入一个节点即可
cluster.initial_master_nodes: ["node-1"]
```
### 3. 运行
```
./elasticsearch-7.4.1/bin/elasticsearch
```
> 报错: org.elasticsearch.bootstrap.StartupException: java.lang.RuntimeException: can not run elasticsearch as root
> 不能再 `root` 账户下运行

### 4. 创建新用户和用户组
```
groupadd elastic
useradd elastic -g elastic

```
### 5. 赋权
```
chown -R elastic:elastic elasticsearch-7.4.1
```
### 6. 运行
> 切换用户
```
su elastic
```
> 运行
```
./elasticsearch-7.4.1/bin/elasticsearch
```
