title: IntellIJ Idea内存不足时怎么设置
date: '2019-08-06 17:18:24'
updated: '2019-08-12 18:25:35'
tags: [IDEA, IntellIJIdea, IDE]
permalink: /articles/2019/08/06/1565083104000.html
---
> 现在越来越多的人投入了 `IntellIJ Idea` 的怀抱, 它给我们的日常开发带来了诸多便利, 但是由于对它的不熟悉, 导致很多时候需要某些设置却不知道怎么去哪里设置, 比如, 在我们导入大项目时, `IntellIJ Idea` 向我们抛出了一个 `OutOfMemoryError` 内存不足, 我们应该怎么设置呢?

#### 1. 打开内存显示
- 打开 **设置Settings**
- 选择 `Appearance & Behavior` 下的 `Appearance`
- 找到 `Windows Options`
- 选中里面的 `Show memory indicator`
- 点击 `OK`
- 内存使用情况会展示在 `IDEA` 的右下角
- `IDEA` 的默认最大内存为 **750M**

![IDEA展示内存状态](http://www.qiniudns.chengzime.com.cn/FluvKrnmnGws9FJxDsabrPUHr_jP)

#### 2. 在`IDEA`中设置内存
- 选择 **Help**
- 选择 `Diagnostic`
- 选择 `Change memory settings`


![IDEA设置内存位置](http://www.qiniudns.chengzime.com.cn/FlA5Kpt3TMnazcRdaF16eX-nc8aN)

- 在弹出的设置框中 **修改** 内存大小, 默认750M
- 下面有显示此设置所在配置文件和路径,当前内存值,根据情况酌情修改
- 配置文件一般都在 `IntellIJ Idea`安装目录下`bin/idea.vmoptions`
- 根据`eclipse`设置的经验这个内存并不是设置的越大越好
- 有时间的可以自己测试一下告诉大家多少最合适.
- 我的机器是24G的,设置1024M和2048M都没有问题.
![IDEA设置内存](http://www.qiniudns.chengzime.com.cn/Fr4PR47Y4tS21bp1b8i0YmbIz-11)

#### 3. 在`IDEA`中打开内存的设置文件
- 你也可以在配置文件里面修改内存大小
- 选择 **Help**
- 选择 `Edit Custom VM Options...` 会打开配置文件
```
-Xms128m
-Xmx750m  # 设置最大内存
-XX:ReservedCodeCacheSize=240m
-XX:+UseConcMarkSweepGC
-XX:SoftRefLRUPolicyMSPerMB=50
-ea
-Dsun.io.useCanonCaches=false
-Djava.net.preferIPv4Stack=true
-Djdk.http.auth.tunneling.disabledSchemes=""
-XX:+HeapDumpOnOutOfMemoryError
-XX:-OmitStackTraceInFastThrow
-Dide.no.platform.update=true
```
![IDEA打开内存配置文件](http://www.qiniudns.chengzime.com.cn/FpY0wCb-745tmEYkBTLVt_ggcAZN)

#### 4. `JetBrains ToolBox` 中安装 `IntellIJ Idea`配置文件位置
> `JetBrains ToolBox`是一个软件盒子, 我们可以从里面直接安装`IntellIJ Idea`, 还能进行更新.
在`JetBrains ToolBox` 中安装 `IntellIJ Idea`内存配置的文件有两个位置:
一个是`IntellIJ Idea`安装目录下`bin/idea.vmoptions`, 这个配置文件修改是不起作用的
另一个配置文件在`IntellIJ Idea`的安装目录同级目录下,`IntellIJ Idea`的安装目录名称为版本号命名,配置文件为 `191.7479.19.vmoptions`
