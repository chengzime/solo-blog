title: sky-walking 配置与安装
date: '2019-10-29 17:31:39'
updated: '2019-10-30 18:18:08'
tags: [skywalking, Linux, CentOS, elasticsearch]
permalink: /articles/2019/10/29/1572341499170.html
---
![](https://img.hacpai.com/bing/20181022.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

### 1. 下载地址
http://skywalking.apache.org/zh/downloads/
> apache-skywalking-apm-6.4.0.tar.gz
elasticsearch-6.8.4.tar.gz
kibana-6.8.4-linux-x86_64.tar.gz

### 2. 解压
```
tar -zxvf apache-skywalking-apm-6.4.0.tar.gz
```
### 3. 配置 `elasticsearch`
> 默认情况下 `skywalking` 使用的存储为 `H2`, 我们可以根据自己的需要修改为 `elasticsearch` 或者 `mysql`, 我下载了 `elasticsearch 7.x`, 启动之后发现报错,
查看文档 `Active ElasticSearch 6 as storage, set storage provider to elasticsearch.
Required ElasticSearch 6.3.2 or higher, excepted 7.0.0 or higher. HTTP RestHighLevelClient is used to connect server.
Setting fragment example` 发现 `elasticsearch` 目前只支持 `6.3.2 - 7.0` 之间的版本: 
```
[root@VM_16_20_centos skywalking]# cd apache-skywalking-apm-bin/config/
[root@VM_16_20_centos config]# ll
total 48
-rw-rw-r-- 1 1001 elastic 1680 Sep  9 02:04 alarm-settings-sample.yml
-rw-rw-r-- 1 1001 elastic 2679 Sep  9 02:04 alarm-settings.yml
-rw-rw-r-- 1 1001 elastic 8449 Oct 30 15:08 application.yml
-rwxrwxr-x 1 1001 elastic 6132 Sep  9 02:04 component-libraries.yml
-rw-rw-r-- 1 1001 elastic 1247 Sep  9 02:04 datasource-settings.properties
-rwxrwxr-x 1 1001 elastic  963 Sep  9 02:04 gateways.yml
-rw-rw-r-- 1 1001 elastic 1814 Sep  9 02:04 log4j2.xml
-rwxrwxr-x 1 1001 elastic 7051 Sep  9 02:04 official_analysis.oal

```
> 配置 `application.yml`
```
vi application.yml
```
```
# Licensed to the Apache Software Foundation (ASF) under one
# or more contributor license agreements.  See the NOTICE file
# distributed with this work for additional information
# regarding copyright ownership.  The ASF licenses this file
# to you under the Apache License, Version 2.0 (the
# "License"); you may not use this file except in compliance
# with the License.  You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

cluster:
   # 单节点模式
  standalone:
  # Please check your ZooKeeper is 3.5+, However, it is also compatible with ZooKeeper 3.4.x. Replace the ZooKeeper 3.5+
  # library the oap-libs folder with your ZooKeeper 3.4.x library.
    # zk用于管理collector集群协作.
#  zookeeper:
#    nameSpace: ${SW_NAMESPACE:""}
#    hostPort: ${SW_CLUSTER_ZK_HOST_PORT:localhost:2181}
#    #Retry Policy
#    baseSleepTimeMs: ${SW_CLUSTER_ZK_SLEEP_TIME:1000} # initial amount of time to wait between retries
#    maxRetries: ${SW_CLUSTER_ZK_MAX_RETRIES:3} # max number of times to retry
#    # Enable ACL
#    enableACL: ${SW_ZK_ENABLE_ACL:false} # disable ACL in default
#    schema: ${SW_ZK_SCHEMA:digest} # only support digest schema
#    expression: ${SW_ZK_EXPRESSION:skywalking:skywalking}
#  kubernetes:
#    watchTimeoutSeconds: ${SW_CLUSTER_K8S_WATCH_TIMEOUT:60}
#    namespace: ${SW_CLUSTER_K8S_NAMESPACE:default}
#    labelSelector: ${SW_CLUSTER_K8S_LABEL:app=collector,release=skywalking}
#    uidEnvName: ${SW_CLUSTER_K8S_UID:SKYWALKING_COLLECTOR_UID}
#  consul:
#    serviceName: ${SW_SERVICE_NAME:"SkyWalking_OAP_Cluster"}
#     Consul cluster nodes, example: 10.0.0.1:8500,10.0.0.2:8500,10.0.0.3:8500
#    hostPort: ${SW_CLUSTER_CONSUL_HOST_PORT:localhost:8500}
#  nacos:
#    serviceName: ${SW_SERVICE_NAME:"SkyWalking_OAP_Cluster"}
#    hostPort: ${SW_CLUSTER_NACOS_HOST_PORT:localhost:8848}
#  etcd:
#    serviceName: ${SW_SERVICE_NAME:"SkyWalking_OAP_Cluster"}
#     etcd cluster nodes, example: 10.0.0.1:2379,10.0.0.2:2379,10.0.0.3:2379
#    hostPort: ${SW_CLUSTER_ETCD_HOST_PORT:localhost:2379}
core:
  default:
    # Mixed: Receive agent data, Level 1 aggregate, Level 2 aggregate
    # Receiver: Receive agent data, Level 1 aggregate
    # Aggregator: Level 2 aggregate
    role: ${SW_CORE_ROLE:Mixed} # Mixed/Receiver/Aggregator
    restHost: ${SW_CORE_REST_HOST:0.0.0.0}
    restPort: ${SW_CORE_REST_PORT:12800}
    restContextPath: ${SW_CORE_REST_CONTEXT_PATH:/}
    gRPCHost: ${SW_CORE_GRPC_HOST:0.0.0.0}
    gRPCPort: ${SW_CORE_GRPC_PORT:11800}
    downsampling:
      - Hour
      - Day
      - Month
    # Set a timeout on metrics data. After the timeout has expired, the metrics data will automatically be deleted.
    enableDataKeeperExecutor: ${SW_CORE_ENABLE_DATA_KEEPER_EXECUTOR:true} # Turn it off then automatically metrics data delete will be close.
    recordDataTTL: ${SW_CORE_RECORD_DATA_TTL:90} # Unit is minute
    minuteMetricsDataTTL: ${SW_CORE_MINUTE_METRIC_DATA_TTL:90} # Unit is minute
    hourMetricsDataTTL: ${SW_CORE_HOUR_METRIC_DATA_TTL:36} # Unit is hour
    dayMetricsDataTTL: ${SW_CORE_DAY_METRIC_DATA_TTL:45} # Unit is day
    monthMetricsDataTTL: ${SW_CORE_MONTH_METRIC_DATA_TTL:18} # Unit is month
    # Cache metric data for 1 minute to reduce database queries, and if the OAP cluster changes within that minute,
    # the metrics may not be accurate within that minute.
    enableDatabaseSession: ${SW_CORE_ENABLE_DATABASE_SESSION:true}
storage:
 elasticsearch:
   # elasticsearch 的集群名称
   nameSpace: ${SW_NAMESPACE:"my-application"}  # 这里改成自己的
   # elasticsearch 集群节点的地址及端口
   clusterNodes: ${SW_STORAGE_ES_CLUSTER_NODES:192.168.100.101:9200}  # 这里改成自己的
   protocol: ${SW_STORAGE_ES_HTTP_PROTOCOL:"http"}
   trustStorePath: ${SW_SW_STORAGE_ES_SSL_JKS_PATH:"../es_keystore.jks"}
   trustStorePass: ${SW_SW_STORAGE_ES_SSL_JKS_PASS:""}
   # elasticsearch 的用户名和密码
   user: ${SW_ES_USER:""}
   password: ${SW_ES_PASSWORD:""}
   # 设置 elasticsearch 索引分片数量
   indexShardsNumber: ${SW_STORAGE_ES_INDEX_SHARDS_NUMBER:1}
   # 设置 elasticsearch 索引副本数
   indexReplicasNumber: ${SW_STORAGE_ES_INDEX_REPLICAS_NUMBER:0}
   # Those data TTL settings will override the same settings in core module.
   recordDataTTL: ${SW_STORAGE_ES_RECORD_DATA_TTL:7} # Unit is day
   otherMetricsDataTTL: ${SW_STORAGE_ES_OTHER_METRIC_DATA_TTL:45} # Unit is day
   monthMetricsDataTTL: ${SW_STORAGE_ES_MONTH_METRIC_DATA_TTL:18} # Unit is month
   # Batch process setting, refer to https://www.elastic.co/guide/en/elasticsearch/client/java-api/5.5/java-docs-bulk-processor.html
   # 批量处理配置
   # 每2000个请求执行一次批量
   bulkActions: ${SW_STORAGE_ES_BULK_ACTIONS:1000} # Execute the bulk every 1000 requests
   # 无论请求的数量如何，每10秒刷新一次堆
   flushInterval: ${SW_STORAGE_ES_FLUSH_INTERVAL:10} # flush the bulk every 10 seconds whatever the number of requests
   # 并发请求的数量
   concurrentRequests: ${SW_STORAGE_ES_CONCURRENT_REQUESTS:2} # the number of concurrent requests
   # elasticsearch 查询的最大数量
   metadataQueryMaxSize: ${SW_STORAGE_ES_QUERY_MAX_SIZE:5000}
   # elasticsearch 查询段最大数量
   segmentQueryMaxSize: ${SW_STORAGE_ES_QUERY_SEGMENT_SIZE:200}
  # h2:
    # driver: ${SW_STORAGE_H2_DRIVER:org.h2.jdbcx.JdbcDataSource}
    # url: ${SW_STORAGE_H2_URL:jdbc:h2:mem:skywalking-oap-db}
    # user: ${SW_STORAGE_H2_USER:sa}
    # metadataQueryMaxSize: ${SW_STORAGE_H2_QUERY_MAX_SIZE:5000}
#  mysql:
#    metadataQueryMaxSize: ${SW_STORAGE_H2_QUERY_MAX_SIZE:5000}
receiver-sharing-server:
  default:
receiver-register:
  default:
receiver-trace:
  default:
    bufferPath: ${SW_RECEIVER_BUFFER_PATH:../trace-buffer/}  # Path to trace buffer files, suggest to use absolute path
    bufferOffsetMaxFileSize: ${SW_RECEIVER_BUFFER_OFFSET_MAX_FILE_SIZE:100} # Unit is MB
    bufferDataMaxFileSize: ${SW_RECEIVER_BUFFER_DATA_MAX_FILE_SIZE:500} # Unit is MB
    bufferFileCleanWhenRestart: ${SW_RECEIVER_BUFFER_FILE_CLEAN_WHEN_RESTART:false}
    sampleRate: ${SW_TRACE_SAMPLE_RATE:10000} # The sample rate precision is 1/10000. 10000 means 100% sample in default.
    slowDBAccessThreshold: ${SW_SLOW_DB_THRESHOLD:default:200,mongodb:100} # The slow database access thresholds. Unit ms.
receiver-jvm:
  default:
receiver-clr:
  default:
service-mesh:
  default:
    bufferPath: ${SW_SERVICE_MESH_BUFFER_PATH:../mesh-buffer/}  # Path to trace buffer files, suggest to use absolute path
    bufferOffsetMaxFileSize: ${SW_SERVICE_MESH_OFFSET_MAX_FILE_SIZE:100} # Unit is MB
    bufferDataMaxFileSize: ${SW_SERVICE_MESH_BUFFER_DATA_MAX_FILE_SIZE:500} # Unit is MB
    bufferFileCleanWhenRestart: ${SW_SERVICE_MESH_BUFFER_FILE_CLEAN_WHEN_RESTART:false}
istio-telemetry:
  default:
envoy-metric:
  default:
#    alsHTTPAnalysis: ${SW_ENVOY_METRIC_ALS_HTTP_ANALYSIS:k8s-mesh}
#receiver_zipkin:
#  default:
#    host: ${SW_RECEIVER_ZIPKIN_HOST:0.0.0.0}
#    port: ${SW_RECEIVER_ZIPKIN_PORT:9411}
#    contextPath: ${SW_RECEIVER_ZIPKIN_CONTEXT_PATH:/}
query:
  graphql:
    path: ${SW_QUERY_GRAPHQL_PATH:/graphql}
alarm:
  default:
telemetry:
  none:
configuration:
  none:
#  nacos:
#    # Nacos Server Host
#    serverAddr: 127.0.0.1
#    # Nacos Server Port
#    port: 8848
#    # Nacos Configuration Group
#    group: 'skywalking'
#    # Unit seconds, sync period. Default fetch every 60 seconds.
#    period : 60
#    # the name of current cluster, set the name if you want to upstream system known.
#    clusterName: "default"
#  zookeeper:
#    period : 60 # Unit seconds, sync period. Default fetch every 60 seconds.
#    nameSpace: /default
#    hostPort: localhost:2181
#    #Retry Policy
#    baseSleepTimeMs: 1000 # initial amount of time to wait between retries
#    maxRetries: 3 # max number of times to retry
#  etcd:
#    period : 60 # Unit seconds, sync period. Default fetch every 60 seconds.
#    group :  'skywalking'
#    serverAddr: localhost:2379
#    clusterName: "default"
#exporter:
#  grpc:
#    targetHost: ${SW_EXPORTER_GRPC_HOST:127.0.0.1}
#    targetPort: ${SW_EXPORTER_GRPC_PORT:9870}

```
### 4. 启动
> 在 `bin` 文件下, 需要端口 `8080, 10800, 11800, 12800`,请确保端口未被占用
```
[root@VM_16_20_centos skywalking]# cd apache-skywalking-apm-bin/bin/
[root@VM_16_20_centos bin]# ll
total 40
-rwxr-xr-x 1 1001 elastic 1352 Sep  9 02:04 oapService.bat
-rwxr-xr-x 1 1001 elastic 1364 Sep  9 02:04 oapServiceInit.bat
-rwxr-xr-x 1 1001 elastic 1597 Sep  9 02:04 oapServiceInit.sh
-rwxr-xr-x 1 1001 elastic 1367 Sep  9 02:04 oapServiceNoInit.bat
-rwxr-xr-x 1 1001 elastic 1616 Sep  9 02:04 oapServiceNoInit.sh
-rwxr-xr-x 1 1001 elastic 1599 Sep  9 02:04 oapService.sh
-rwxr-xr-x 1 1001 elastic  941 Sep  9 02:04 startup.bat   # windows 启动这个
-rwxr-xr-x 1 1001 elastic  934 Sep  9 02:04 startup.sh    # linux 启动这个
-rwxr-xr-x 1 1001 elastic 1426 Sep  9 02:04 webappService.bat
-rwxr-xr-x 1 1001 elastic 1630 Sep  9 02:04 webappService.sh
```
> 此系统分为两部分, `oapService` 和 `webappService`, 可以单独启动, 也可以使用 `startup` 进行一键启动
```
./startup.sh
```
### 5. 查看监控界面 
```
192.168.100.101:8080
```

### 6. 配置 `agent`
- 什么是`agent`: 获取项目的接口请求、查询`sql`、`jvm`等信息，并将这些信息上传给`collector`, `agent`为客户端包
- 怎么使用 : 解压目录下的 `agent` 目录即所需的所有文件, 如果需要监控的项目在本机, 则可以不用动此目录, 如果在其他机器, 那么需要把此整个目录一起复制到项目所在的机器上
- 怎么运行 : 启动项目配置 `JVM` 参数的时候配置 `agent` 的相关参数, 需要配置`skywalking-agent.jar` 文件
> 我的配置如下: 
首先配置 `agent.config`
```
# Licensed to the Apache Software Foundation (ASF) under one
# or more contributor license agreements.  See the NOTICE file
# distributed with this work for additional information
# regarding copyright ownership.  The ASF licenses this file
# to you under the Apache License, Version 2.0 (the
# "License"); you may not use this file except in compliance
# with the License.  You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

# The agent namespace
# agent.namespace=${SW_AGENT_NAMESPACE:default-namespace}

# The service name in UI
agent.service_name=${SW_AGENT_NAME:cms} # 项目名称

# The number of sampled traces per 3 seconds
# Negative number means sample traces as many as possible, most likely 100%
# agent.sample_n_per_3_secs=${SW_AGENT_SAMPLE:-1}

# Authentication active is based on backend setting, see application.yml for more details.
# agent.authentication = ${SW_AGENT_AUTHENTICATION:xxxx}

# The max amount of spans in a single segment.
# Through this config item, skywalking keep your application memory cost estimated.
# agent.span_limit_per_segment=${SW_AGENT_SPAN_LIMIT:300}

# Ignore the segments if their operation names end with these suffix.
# agent.ignore_suffix=${SW_AGENT_IGNORE_SUFFIX:.jpg,.jpeg,.js,.css,.png,.bmp,.gif,.ico,.mp3,.mp4,.html,.svg}

# If true, skywalking agent will save all instrumented classes files in `/debugging` folder.
# Skywalking team may ask for these files in order to resolve compatible problem.
# agent.is_open_debugging_class = ${SW_AGENT_OPEN_DEBUG:true}

# The operationName max length
# agent.operation_name_threshold=${SW_AGENT_OPERATION_NAME_THRESHOLD:500}

# Backend service addresses.
collector.backend_service=${SW_AGENT_COLLECTOR_BACKEND_SERVICES:192.168.100.101:11800}  # 此处配置 skywalking 服务端所在的 ip

# Logging file_name
logging.file_name=${SW_LOGGING_FILE_NAME:skywalking-api.log}

# Logging level
logging.level=${SW_LOGGING_LEVEL:DEBUG}

# Logging dir
# logging.dir=${SW_LOGGING_DIR:""}

# Logging max_file_size, default: 300 * 1024 * 1024 = 314572800
# logging.max_file_size=${SW_LOGGING_MAX_FILE_SIZE:314572800}

# mysql plugin configuration
# plugin.mysql.trace_sql_parameters=${SW_MYSQL_TRACE_SQL_PARAMETERS:false}
```
> 保存 `agent.config`, 运行项目
```
java -javaagent:/home/skywalking/apache-skywalking-apm-bin/agent/skywalking-agent.jar  -jar test.jar
```
> 配置时路径为绝对路径, 我们启动完成之后, 调用此项目的接口, 然后查看监控界面发现已经可以正常监控到访问数据, 但是我们如果需要部署多个项目时, 发现一个 `agent.config` 显然不太够用, 因为我们每个项目都需要他自己的名字, 所以我们需要添加配置, 复制一份 `agent.config`, 根据项目取名 `cms.config`, 在新配置文件中配置所属项目的配置等, 然后在启动项目时新增配置: 
```
 -Dskywalking_config=/home/skywalking/apache-skywalking-apm-bin/agent/config/cms.config 
```
> 其他项目部署时一样

### 7. 官方文档
`https://github.com/apache/skywalking/blob/master/docs/README.md`
