title: 修改 Docker 的镜像源地址
date: '2019-08-19 14:28:33'
updated: '2019-08-19 14:28:33'
tags: [CentOS, Linux, Docker]
permalink: /articles/2019/08/19/1566196113907.html
---
我们在使用 `Docker` 拉取镜像的时候, 经常会出现比如 `速度太慢` 或者 `下载卡住不动` 等情况, 遇到这种情况我们需要用到 `Docker` 加速器, 即国内的镜像源地址/代理.

#### 1. 国内比较常用的几个镜像源地址
-  [中国科技大学](http://mirrors.ustc.edu.cn/help/dockerhub.html?highlight=docker)
```
https://docker.mirrors.ustc.edu.cn
```

- [阿里云](https://cr.console.aliyun.com/cn-hangzhou/instances/mirrors)
```
https://0pavghl8.mirror.aliyuncs.com
```
- Docker 官方中国区
```
https://registry.docker-cn.com
```
- 网易云
```
http://hub-mirror.c.163.com
```

#### 2. 修改或新建 `/etc/docker/daemon.json` 文件
```
vi /etc/docker/daemon.json
```
按 `i` 加入配置
```
{
  "registry-mirrors": ["https://docker.mirrors.ustc.edu.cn/"]
}
```
按 `Esc`, 输入 `:wq` 保存退出

#### 3. 重启 `Docker`
```
systemctl restart docker
```

