title: max virtual memory areas vm.max_map_count [65530] is too low, increase to at
  least [262144]
date: '2019-10-28 17:48:20'
updated: '2019-10-28 17:48:25'
tags: [CentOS, Linux, elasticsearch]
permalink: /articles/2019/10/28/1572256100073.html
---
> 在 `Linux` 中安装 `elasticsearch` 的时候碰到了这个错误:
`max virtual memory areas vm.max_map_count [65530] is too low, increase to at least [262144]`

### 解决办法:
- 切换到 `root` 用户修改配置
```
vi /etc/sysctl.conf 
```
- 添加下面配置
```
vm.max_map_count=262144
```
- 执行命令
```
sysctl -p
```
