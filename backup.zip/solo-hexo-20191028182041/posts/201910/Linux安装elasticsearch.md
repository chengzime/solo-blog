title: Linux 安装 elasticsearch
date: '2019-10-28 17:30:44'
updated: '2019-10-28 17:30:44'
tags: [elasticsearch, CentOS, Linux]
permalink: /articles/2019/10/28/1572255044387.html
---
> 使用的 `centos 7.x`
### 1. 下载地址: 
https://www.elastic.co/cn/products/elastic-stack
> 下载完成导入 `linux`
### 2. 解压
```
tar -zxvf elasticsearch-7.4.1-linux-x86_64.tar.gz
```
### 3. 运行
```
./elasticsearch-7.4.1/bin/elasticsearch
```
> 报错: org.elasticsearch.bootstrap.StartupException: java.lang.RuntimeException: can not run elasticsearch as root
> 不能再 `root` 账户下运行

### 4. 创建新用户和用户组
```
groupadd elastic
useradd elastic -g elastic -p elasticsearch

```
### 5. 赋权
```
chown -R elastic:elastic elasticsearch-7.4.1
```
### 6. 运行
> 切换用户
```
su elastic
```
> 运行
```
./elasticsearch-7.4.1/bin/elasticsearch
```
