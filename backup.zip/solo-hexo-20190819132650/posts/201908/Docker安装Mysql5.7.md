title: Docker 安装 Mysql 5.7
date: '2019-08-07 19:00:05'
updated: '2019-08-19 11:50:51'
tags: [Mysql, Docker, Linux, CentOS]
permalink: /articles/2019/08/07/1565175605000.html
---
#### 1. 查看 `docker` 本地镜像
```
docker images
```
#### 2. 本地没有, 查询 `mysql` 镜像
```
docker search mysql
```
#### 3. 拉取所需的镜像, 版本号根据所需
```
docker pull mysql:5.7
```
#### 4. 安装 `mysql`
```
docker run -p 3306:3306 --name mysql -e MYSQL_ROOT_PASSWORD=123456  -d mysql:5.7 --character-set-server=utf8mb4 --collation-server=utf8mb4_unicode_ci
或者
docker run -p 3306:3306 --name mysql -v ~/mysql/conf:/etc/mysql/conf.d -v ~/mysql/logs:/logs -v ~/mysql/data:/var/lib/mysql -e MYSQL_ROOT_PASSWORD=123456  -d mysql:5.7 --character-set-server=utf8mb4 --collation-server=utf8mb4_unicode_ci
```
命令说明:
```
    -p 3306:3306 : 将容器的 3306 端口映射到主机的 3306 端口

    -v ~/mysql/conf:/etc/mysql/conf.d : 将主机当前目录下的 conf/my.cnf 挂载到容器的 /etc/mysql/my.cnf

    -v ~/mysql/logs:/logs : 将主机当前目录下的 logs 目录挂载到容器的 /logs

    -v ~/mysql/data:/var/lib/mysql : 将主机当前目录下的 data 目录挂载到容器的 /var/lib/mysql

    -e MYSQL_ROOT_PASSWORD=123456 : 初始化 root 用户的密码

    -d mysql5.7 : 后台运行 mysql5.7,并返回容器ID
    
    --name mysql : 设置容器名称

    --rm : 容器停止运行自动删除
```
#### 5. 查看容器运行情况
```
docker ps

# 打印
CONTAINER ID        IMAGE               COMMAND                  CREATED             STATUS              PORTS                               NAMES
ee124d2c7219        mysql:5.7           "docker-entrypoint.s…"   5 minutes ago       Up 5 minutes        0.0.0.0:3306->3306/tcp, 33060/tcp   mysql
```
#### 6. 进入容器
```
docker exec -it mysql bash  # 进入容器
exit # 退出容器
```
#### 7. 登陆 `mysql`
```
mysql -u root -p  # 然后输入密码登陆
exit # 退出
```
#### 8. 设置容器自动启动
```
docker update --restart=always mysql  # 最后为容器名称
```
#### 9. 删除容器
```
# 查看是否在运行
docker ps
# 查看所有容器包括停止运行的
docker ps -a
# 停止容器
docker stop 容器名称/id
# 删除容器
docker rm 容器名称/id
```
