title: VirtualBox虚拟机中对CentOS7配置联网固定IP地址
date: '2019-08-02 10:26:35'
updated: '2019-08-19 11:15:26'
tags: [虚拟机, Linux, 固定IP, virtualbox]
permalink: /articles/2019/08/02/1564712795000.html
---
我们在 `VirtualBox` 中安装了 `CentOS7`, 但是发现我们无法连接网络,比如: 百度`www.baidu.com`,我们宿主机和虚拟机中的系统网络也能联通, 或者我们可以连接网络,但是我们虚拟机系统的`ip`不是固定的,我们该怎么做?

### 1. 对宿主机的`VirtualBox Host-Only Network`网络设置固定ip
- 打开 **网络连接**
- 找到 `VirtualBox Host-Only Network`


![VirtualBox Host-Only Network](http://www.qiniudns.chengzime.com.cn/FmrS0dXrk-9-_yfF7lbjBRBIUW5h)

- 右击 选择 **属性**
- 选择 `internet协议版本4(TCP/IPv4)`
- 点击 **属性**

![选择IPv4协议](http://www.qiniudns.chengzime.com.cn/FrnyLLnuoGlfYsy1oQryfz4rm7DB)

- 根据自己的需要设置**宿主机**的**固定 `ip` 地址**


![设置固定ip](http://www.qiniudns.chengzime.com.cn/FkD6JXZvCgVcHpfeJABEYt2YXDBi)

### 2. `virtualbox` 中对应的虚拟系统进行网卡设置
- 选择 **对应系统**
- 点击 **设置**
- 选择 **网络**
- 选择 **网卡1**
- **连接方式** 选择-> **仅主机(Host-Only)网络**
- 此网络可以保证**虚拟系统可以和宿主机互通**
- 保存

![网卡1](http://www.qiniudns.chengzime.com.cn/FrRGIt1CaXn5jf_qeJDcihGBX-_h)

- 选择 **网卡2**
- 启用网络连接
- **连接方式** 选择 ** 网络地址转换**
- 此网络可以保证**虚拟系统可以联网**
- 保存


![网卡2](http://www.qiniudns.chengzime.com.cn/FjJIY-HCA_HSekWDan0LXUFdKQMM)

### 3. 启动系统,修改编辑 `enp0s3` 和 `enp0s8` 网卡
- `enp0s3` 与宿主机互通
- `enp0s8` 虚拟系统联网

- 进入 `vi` 编辑模式编辑`enp0s3`文件

```
vi /etc/sysconfig/network-scripts/ifcfg-enp0s3
```

- 按 `i` 开始进行编辑
```
TYPE=Ethernet
PROXY_METHOD=none
BROWSER_ONLY=no
BOOTPROTO=static    #使用静态ip
DEFROUTE=yes
IPV4_FAILURE_FATAL=no
IPV6INIT=yes
IPV6_AUTOCONF=yes
IPV6_DEFROUTE=yes
IPV6_FAILURE_FATAL=no
IPV6_ADDR_GEN_MODE=stable-privacy
NAME=enp0s3
UUID=4e487aa9-0561-4c75-9696-d7fd7c835264
DEVICE=enp0s3
ONBOOT=yes      #设置开机启动
IPADDR=192.168.100.1   #设置宿主机的静态ip地址
```
- 按`Esc`此处编辑模式
- 输入`:wq`保存退出 `vi` 模式


- 进入 `vi` 编辑模式编辑`enp0s8`文件
- 如果`enp0s8`文件不存在
- 复制一份`cp ifcfg-enp0s3 ifcfg-enp0s8`

```
vi /etc/sysconfig/network-scripts/ifcfg-enp0s8
```
- 按 `i` 开始进行编辑
```
TYPE=Ethernet
PROXY_METHOD=none
BROWSER_ONLY=no
BOOTPROTO=dhcp   #确认此处是dhcp，为动态ip
DEFROUTE=yes
IPV4_FAILURE_FATAL=no
IPV6INIT=yes
IPV6_AUTOCONF=yes
IPV6_DEFROUTE=yes
IPV6_FAILURE_FATAL=no
IPV6_ADDR_GEN_MODE=stable-privacy
NAME=enp0s8
UUID=4e367bb9-0561-4c75-9b96-d7fd7c8324e3
DEVICE=enp0s8
ONBOOT=yes    #设置开机启动
```
- 按`Esc`此处编辑模式
- 输入`:wq`保存退出 `vi` 模式

### 4. 重启网络
```
#centos7 版本的重启网络服务
systemctl start network
#老版本的 重启网络服务
service network restart
```

### 5. 测试网络
```
ping www.baidu.com
ping 192.168.100.1
ping 192.168.100.101
```

