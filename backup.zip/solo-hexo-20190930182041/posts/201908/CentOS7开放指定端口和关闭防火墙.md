title: CentOS7 开放指定端口和关闭防火墙
date: '2019-08-15 15:06:07'
updated: '2019-08-19 12:00:28'
tags: [CentOS, Linux, 防火墙]
permalink: /articles/2019/08/15/1565852767719.html
---
我们在 `Linux` 上部署项目的时候, 经常会遇到运行正常的项目, 在本机可以正常访问的, 但是在宿主机或者其他机器无法访问, 遇到这种问题, 很可能是端口号被防火墙拦截了, 那么我们怎么对外开放我们想要使用的端口号呢 ? 

#### 1. 查询防火墙状态
- 使用
```
systemctl status firewalld
```
```
# 已启动的状态
[root@localhost ~]# systemctl status firewalld
● firewalld.service - firewalld - dynamic firewall daemon
   Loaded: loaded (/usr/lib/systemd/system/firewalld.service; enabled; vendor preset: enabled)
   Active: active (running) since 四 2019-08-15 14:01:20 CST; 42min ago
     Docs: man:firewalld(1)
 Main PID: 18631 (firewalld)
    Tasks: 2
   Memory: 25.4M
   CGroup: /system.slice/firewalld.service
           └─18631 /usr/bin/python -Es /usr/sbin/firewalld --nofork --nopid

...(省略)
Hint: Some lines were ellipsized, use -l to show in full.

# 未启动的状态
[root@localhost ~]# systemctl status firewalld
● firewalld.service - firewalld - dynamic firewall daemon
   Loaded: loaded (/usr/lib/systemd/system/firewalld.service; enabled; vendor preset: enabled)
   Active: inactive (dead) since 四 2019-08-15 14:47:13 CST; 3s ago
     Docs: man:firewalld(1)
  Process: 18631 ExecStart=/usr/sbin/firewalld --nofork --nopid $FIREWALLD_ARGS (code=exited, status=0/SUCCESS)
 Main PID: 18631 (code=exited, status=0/SUCCESS)

...(省略)
Hint: Some lines were ellipsized, use -l to show in full.

```
- 或者 使用 
```
firewall-cmd --state
```
```
# 已启动状态
[root@localhost ~]# firewall-cmd --state
running

# 未启动的状态
[root@localhost ~]# firewall-cmd --state
not running
```
#### 2. 开启/停止防火墙
- 开启防火墙 
```
systemctl start firewalld
```
- 停止防火墙 
```
systemctl stop firewalld
```
- 重启防火墙 
```
systemctl restart firewalld
```

#### 3. 开机启动
- 查询是否开机启动 
```
systemctl is-enabled firewalld
```
```
# 开机启动
[root@localhost ~]# systemctl is-enabled firewalld
enabled
# 非开机启动
[root@localhost ~]# systemctl is-enabled firewalld
disable
```
- 设置开机启动 
```
systemctl enable firewalld
```
- 关闭开机启动 
```
systemctl disable firewalld
```

#### 4. 查询已开放的端口
```
firewall-cmd --list-ports
```
```
[root@localhost ~]# firewall-cmd --list-ports
8080/tcp
```
#### 5. 开通指定的端口
- 我们以 `8080` 为例

```
firewall-cmd --permanent --add-port=8080/tcp

firewall-cmd --reload
```
- `firewall-cmd` : 防火墙的命令之一
- `--permanent` : 如果不加此参数, 配置立即生效, 防火墙重启后会丢失, 配置了此参数, 会将此配置保存下来, 永久生效, 但是需要重新 `reload` 才会生效
- `--add-port=8080/tcp` : 添加端口  端口/协议
#### 6. 重新加载配置
```
firewall-cmd --reload
```
```
[root@localhost ~]# firewall-cmd --reload
success
```
> 重新加载配置完成即生效
#### 7. 怎么删除已开放的端口
```
firewall-cmd --permanent --remove-port=8080/tcp

firewall-cmd --reload
```
> 新增移除完成需要 `firewall-cmd --reload` 生效

#### 8. 查看系统监听的端口号
```
netstat   -tunlp
```

```
[root@VM_0_6_centos ~]# netstat   -tunlp
Active Internet connections (only servers)
Proto Recv-Q Send-Q Local Address           Foreign Address         State       PID/Program name    
tcp        0      0 0.0.0.0:8081            0.0.0.0:*               LISTEN      7339/java           
tcp        0      0 0.0.0.0:22              0.0.0.0:*               LISTEN      993/sshd            
tcp        0      0 0.0.0.0:8888            0.0.0.0:*               LISTEN      1770/java           
tcp6       0      0 :::80                   :::*                    LISTEN      11640/docker-proxy  
tcp6       0      0 :::443                  :::*                    LISTEN      11629/docker-proxy  
tcp6       0      0 :::3306                 :::*                    LISTEN      1278/mysqld         
udp        0      0 0.0.0.0:68              0.0.0.0:*                           907/dhclient        
udp        0      0 172.27.0.6:123          0.0.0.0:*                           528/ntpd            
udp        0      0 127.0.0.1:123           0.0.0.0:*                           528/ntpd            
udp        0      0 0.0.0.0:41183           0.0.0.0:*                           907/dhclient        
udp6       0      0 :::34938                :::*                                907/dhclient
```
- -a 显示所有
- -n 以ip形式显示当前建立的有效连接和端口
- -u 显示UDP协议
- -t 显示TCP协议
- -p 显示对应PID与程序名
