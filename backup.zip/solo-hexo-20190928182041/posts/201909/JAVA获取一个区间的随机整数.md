title: JAVA 获取一个 区间 的随机整数
date: '2019-09-11 18:55:56'
updated: '2019-09-11 18:57:15'
tags: [随机数, JAVA, Random]
permalink: /articles/2019/09/11/1568199355949.html
---
### 1. 公式
- `n、m` 均为整数
- `n < m`
- 生成 `n、m` 之间的整数, 包含 `n、m`
- `new Random().nextInt(m - n + 1 ) + n`

### 2. 工具类
```
package cn.com.chengzi.domain.util;

import java.util.Random;

/**
 * 说明: 随机数
 *
 * @author :chengzi
 * Create :2019/9/11 18:21
 */
public class RandomUtil {

    private static Random random;

    /**
     * 获取一个 区间 的随机 整数
     * @param from 开始(包含)
     * @param to 结束(包含)
     * @return 随机值
     */
    public static Integer randomFromTo(Integer from, Integer to){
        return getRandom().nextInt(to -from + 1) + from;
    }


    private static Random getRandom(){
        if(random == null){
            synchronized (RandomUtil.class){
                if(random == null){
                    random = new Random();
                }
            }
        }
        return random;
    }

    private RandomUtil() {
    }
}

```

### 3. 测试用例
```
package cn.com.chengzi;

import cn.com.chengzi.drools.domain.util.RandomUtil;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.ArrayList;
import java.util.List;

/**
 * 说明:
 *
 * @author :chengzi
 * Create :2019/9/11 15:23
 */
@RunWith(SpringRunner.class)
@SpringBootTest
public class Tests {

    @Test
    public void randomTest(){
        Integer from = -10;
        Integer to = 10;
        for (int i = 0; i < 1000; i++) {
            Integer random = RandomUtil.randomFromTo(from, to);
            System.out.println(random);
            if(random < from || random > to){
                System.out.println("::::::::::::::::::::::::::::::::::::::::::::::::::----- :" + random);
            }
        }
    }
}

```
